# TODO — Task 3

**Name:** ________  **Date:** ________

1) Results summary
- Dominant outcomes: __________________________
- Rough proportions: __________________________

2) Why correlated? (1–3 lines)
- [ ] ____________________________________________
- [ ] ____________________________________________

3) Evidence
- [ ] I ran `python task-3/task_3.py`
- [ ] PNG saved at `outputs/task3/bell_counts.png`

# TODO — Task 5

**Name:** ________  **Date:** ________

1) Report numbers (copy from `outputs/task5/hybrid_report.txt`)
- Baseline accuracy: __________
- Quantum-encoded accuracy: __________
- reps: __________

2) Interpretation (2–4 lines)
- [ ] ____________________________________________
- [ ] ____________________________________________
- [ ] ____________________________________________

3) Variants tried (optional)
- [ ] Changed reps → effect: ______________________
- [ ] Used SVM (kernel=____) → effect: ____________

4) Evidence
- [ ] I ran `python task-5/task_5.py`
- [ ] Report saved to `outputs/task5/hybrid_report.txt`

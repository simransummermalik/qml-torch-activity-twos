# answer-tasks

Reference implementations of the five tasks. **Don’t edit** these; they’re for checking your results after you attempt the matching `task-*` script.

Files:
- `task1_hello_qubits.py`
- `task2_measure_superposition.py`
- `task3_entanglement.py`
- `task4_feature_maps.py`
- `task5_hybrid_classifier.py`

# TODO — Task 4

**Name:** ________  **Date:** ________

1) Inputs you used
- x1: ________   x2: ________   reps: ________

2) Observations (2–3 bullets)
- [ ] ____________________________________________
- [ ] ____________________________________________
- [ ] ____________________________________________

3) Amplitudes you found interesting (paste 1–3 lines + comment)
- [ ] ____________________________________________
- [ ] ____________________________________________

4) Evidence
- [ ] I ran `python task-4/task_4.py`
- [ ] Both files exist in `outputs/task4/`

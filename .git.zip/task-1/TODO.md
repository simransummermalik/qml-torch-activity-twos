# TODO — Task 1

**Name:** ________  **Date:** ________

1) Quick observations (2–3 bullets)
- [ ] ____________________________________________
- [ ] ____________________________________________
- [ ] ____________________________________________

2) Check artifacts
- [ ] I ran `python task-1/task_1_qubit.py`
- [ ] I see four PNGs in `outputs/task1/`

3) (Optional) Experiments tried (H|1⟩, add Z, etc.)
- [ ] ____________________________________________

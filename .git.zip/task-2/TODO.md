# TODO — Task 2

**Name:** ________  **Date:** ________

1) Run details
- Shots used: __________
- Counts observed: ______________________________________

2) Interpretation (1–3 lines). Why ~50/50 in Z-basis after H?
- [ ] ____________________________________________
- [ ] ____________________________________________

3) Evidence
- [ ] I ran `python task-2/task_2.py`
- [ ] PNG saved at `outputs/task2/superposition_measurement_hist.png`
